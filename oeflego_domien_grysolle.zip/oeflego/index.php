<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('data.php');
?>
<!DOCTYPE html>
<html lang="en" data-lt-installed="true">

<head>
    <link rel="icon" href="https://via.placeholder.com/70x70">
    <link rel="stylesheet" href="https://unpkg.com/mvp.css">

    <meta charset="utf-8">
    <meta name="description" content="My description">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>lego lego</title>
</head>

<body>
    <main>
        <section>
            <header>
                <h2>Lego</h2>
                <p>Totaal : <?= count($photos) ?> foto's</p>
            </header>

            <?php foreach ($photos as $index => $photo): ?>

                <aside style="background-color:<?= $photos[$index]['color']; ?>">
                    <a href="lego_detail.php?id=<?php echo $index; ?>">
                        <img src="<?php echo $photo['url']; ?>" />
                    </a>
                </aside>

            <?php endforeach; ?>

        </section>
    </main>

</body>

</html>